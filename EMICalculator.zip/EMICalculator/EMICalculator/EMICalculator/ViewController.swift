//
//  ViewController.swift
//  EMICalculator
//
//  Created by Datta,M Kartikeya on 4/9/24.
//

import UIKit

class ViewController: UIViewController {
    
    var loanType = ""
    var loanAmount = ""
    var interestRate = ""
    var totalMonths = 0.0
    var monthlyInterestRate = 0.0
    var monthlyEMIPayment = 0.0
    var image = ""
    
    @IBOutlet weak var loanTypeOL: UITextField!
    
    @IBOutlet weak var loanAmountOL: UITextField!
    
    @IBOutlet weak var interestRateOL: UITextField!
    
    @IBOutlet weak var TermOL: UITextField!
    
    @IBOutlet weak var calculayeEMIOL: UIButton!
    
    @IBOutlet weak var resetOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        calculayeEMIOL.isEnabled = false
        resetOL.isEnabled = false
    }
    
    
    @IBAction func textOLFunction (_ sender: Any){
        if(loanTypeOL.text!.isEmpty || loanAmountOL.text!.isEmpty || interestRateOL.text!.isEmpty || TermOL.text!.isEmpty){
            calculayeEMIOL.isEnabled = false
            resetOL.isEnabled = false
        }
        else{
            calculayeEMIOL.isEnabled = true
            resetOL.isEnabled = true
        }
    }
    
    
    
    @IBAction func CalcuateEMI(_ sender: Any) {
        loanType = loanTypeOL.text!
        loanAmount = loanAmountOL.text!
        interestRate = interestRateOL.text!
        totalMonths = Double(TermOL.text!)!*12.0
        monthlyInterestRate = (Double(interestRateOL.text!)!/12)/100
        //
       // monthlyEMIPayment = loanAmount! * (monthlyInterestRate * pow(1 + monthlyInterestRate,totalMonths)) / (pow(1 //monthlyInterestRate,totalMonths) - 1)

        monthlyEMIPayment = Double(loanAmountOL.text!)!*(monthlyInterestRate*pow(1+monthlyInterestRate, totalMonths))/(pow(1+monthlyInterestRate, totalMonths) - 1)
        if(loanTypeOL.text == "Car"){
            image = "Car"
        } else if(loanTypeOL.text == "Home"){
            image = "Home"
        }else {
            image = "Personal"
        }
        
    }
    @IBAction func Reset(_ sender: Any) {
        loanTypeOL.text = ""
        loanAmountOL.text = ""
        interestRateOL.text = ""
        TermOL.text = ""
        calculayeEMIOL.isEnabled = false
        resetOL.isEnabled = false
    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        //set the destination
        if(transition == "resultSegue"){
            let destination = segue.destination
            as! ResultViewController
            destination.image = image
            destination.loanType = loanType
            destination.loanAmount = loanAmount
            destination.interestRate = interestRate
            destination.monthlyEMIPayment = monthlyEMIPayment
            
        }
    }
}

